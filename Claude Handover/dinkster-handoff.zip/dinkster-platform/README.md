# Dinkster hand-off package

Start with docs/DINKSTER_CONTEXT_EXPORT.md. Section 0 is the paste-in summary.

- mockups/dinkster-mobile-v6.html : player app (open in a browser, use the toolbar for iPad, Watch, themes)
- mockups/dinkster-web-v5.html : organizer, desk, referee, copilot
- docs/ARCHITECTURE.md : wings, copilot guardrails, roadmap
- docs/V3_V4_REVIEW.md : audit of v3 and v4, fix log for v5
- prisma/schema.prisma : organizer platform schema (needs rework for the split backend)

All mockup data is mock. Nothing persists on refresh.
