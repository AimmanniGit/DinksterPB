# Dinkster Architecture

Status: draft v0.1
Decision basis: offline sync is not a current requirement, so one backend serves all wings.

## 1. Principles

- One identity (Dinkster ID `DK-XXXXX`), one Match record, one backend.
- Two products for two audiences: the Player app (mobile, Wing 1) and the Organizer platform (web, Wings 2, 3, 4). The organizer wings are suppressed from the player app. See DINKSTER_CONTEXT_EXPORT.md.
- Copilot never writes directly. It proposes, previews impact, waits for confirmation, then executes through the same service layer humans use.
- Start simple. Each phase ships a usable slice.

## 2. Platform map

| Layer | Choice | Notes |
|---|---|---|
| Player app | React Native, Expo, TypeScript | Existing scaffold. Data layer swaps from Firebase to Supabase client |
| Organizer and Desk app | Next.js App Router, Tailwind | Web, tablet-friendly kiosk mode |
| Database | Supabase Postgres, Prisma | Schema in `prisma/schema.prisma` |
| Realtime | Supabase Realtime | Court calls, score alerts, schedule deltas |
| Auth | Supabase Auth | Replaces Firebase Auth. Apple Sign-in required for iOS |
| Payments | Stripe Connect | Split payouts, platform fee in basis points |
| Rating | DUPR API | Sync formatter with retry queue |
| Agent | Anthropic API, tool calling, MCP | See section 5 |
| Watch | WatchConnectivity via phone | No direct backend access from Watch |

## 3. Wings, audiences, surfaces

| Wing | Audience | Surface | Core data |
|---|---|---|---|
| 1 Player | Players, coaches | Mobile | User, Match, MatchParticipant, ScoreSet |
| 2 Court Desk | Desk staff, referees | Web and tablet | Court, Match, RefAssignment, Dispute, Incident |
| 3 Hosting | Organizers (entrant-side flows deferred, not in the player app) | Web (organizer) | Tournament, Division, Registration, Payment, Waiver, Sponsor |
| 4 Copilot | Organizers first, then desk, then players | Chat panel in each surface | CopilotSession, CopilotToolCall, MatchChangeLog |

## 4. Where the worlds could meet later (deferred, not in the player app)

Decision (founder): Wings 2, 3, 4 are a different audience and stay out of the player app for now. The points below are kept only as a record of future bridge options.

1. Registration: entrant in Wing 3 is a Wing 1 player.
2. Court call: Wing 2 pushes summons to player devices.
3. Results: tournament matches feed player history and DUPR.
4. Score authority: one Match, multiple score sources.
5. Role overlap: organizers are also players.

### Score authority rule

Precedence: `HOST_OVERRIDE` > `REFEREE` > `SELF_REPORTED` > `IMPORTED`.
A lower-precedence source cannot overwrite a higher one. Self-reported scores on tournament matches are advisory until a referee or desk confirms.
Host override on casual games is silent to other players (locked decision).

## 5. Agentic copilot vision

One agent core, three personas by surface.

### Personas

- **Organizer copilot (Wing 4, core):** drafts a tournament from conversation in under 15 minutes. Defines custom formats and scoring. Pivots rules and schedule live.
- **Desk copilot (Wing 2):** suggests court reassignment, drafts dispute summaries for the human decision, flags overruns.
- **Player copilot (Wing 1):** parses score messages, finds games, answers schedule questions.

### Tool tiers

| Tier | Behavior | Examples |
|---|---|---|
| Read | Executes immediately | `get_schedule`, `get_match`, `list_courts`, `estimate_finish_times` |
| Propose | Writes a `PROPOSED` tool call with computed `preview` | `draft_tournament`, `define_custom_scoring`, `apply_mid_tournament_rule_pivot`, `reassign_court` |
| Commit | Runs only after human confirm | Executes the proposal, writes `MatchChangeLog` |
| Notify | Runs after commit | `trigger_schedule_delta_alert` |

### Guardrails (enforced in code, not only in prompts)

1. Never modify a `COMPLETED` match. Service layer rejects. A Postgres trigger rejects as a second line.
2. Rule overrides apply only to `SCHEDULED` or `PENDING` matches.
3. Every proposal includes the finish-time delta before confirm.
4. Every executed change writes `before` and `after` to `MatchChangeLog`.
5. Optimistic lock via `Match.version`. Stale proposals fail and re-propose.
6. Organizer scope check: the copilot can only touch tournaments the user organizes.
7. Player persona has read access plus score submission only.

### Expanded scope (beyond original Wing 4)

- Rollback: one-step undo of the last executed pivot using `MatchChangeLog`.
- What-if: simulate a pivot without proposing it.
- Division builder: suggest divisions from registration counts and DUPR spread.
- Auto-seeding assistant: propose seeds from DUPR, organizer confirms.
- Day-of digest: summary of delays, open disputes, incidents for the organizer.
- Eval harness: scripted scenarios that must pass before any prompt or tool change ships.

## 6. Data flows

**Registration (deferred bridge, not in the player app):** Entrant surface > Division list > Waiver sign > Stripe PaymentIntent (Connect, fee in bps) > webhook > `Registration.CONFIRMED`.

**Live pivot:** Organizer chat > `apply_mid_tournament_rule_pivot(match_ids, json)` > validate states > compute delta > `PROPOSED` call shown with preview > confirm > transaction updates `customRuleConfig`, bumps `rulesVersion`, logs change > Realtime event > desk and player apps update.

**Casual score:** Player text > parser > validated payload > `ScoreSet` (`SELF_REPORTED`) > other side confirms or host overrides > `COMPLETED` > DUPR queue.

## 7. Risks

| Risk | Mitigation |
|---|---|
| Migration from Firebase delays TestFlight | Port auth and lobby first, keep Firestore read-only until cutover |
| Copilot misapplies a rule change | Propose and confirm tiers, change log, rollback, eval harness |
| Stripe webhook failure leaves registration unpaid | Idempotent handler, reconciliation job |
| DUPR API unavailable | Retry queue, results never block on sync |
| Row-level security gaps expose organizer data | RLS policies per role, tested in `tests/` |
| Scope growth | Phase gates below, each ships independently |

## 8. Roadmap (revised)

| Phase | Scope | Exit check |
|---|---|---|
| 0 | Backend decision, Supabase project, Auth, RLS baseline, Firebase cutover plan | Login works on RN and web |
| 1 | Schema, types, migrations, seed data | Schema deployed, seed loads |
| 2 | Wing 4 core: tools, guardrails, change log, eval harness | All guardrail evals pass |
| 3 | Wing 3: registration, waiver, Stripe split, seeding | Test-mode entry paid and refunded |
| 4 | Wing 2: court desk, referee scoring, disputes, kiosk | Full mock tournament runs on desk |
| 5 | Wing 1 social loop (swipe, match, chat, propose, play), score parser, DUPR sync | Two players match, plan, play, and see the result |
| 6 | Desk and player copilots, rollback, what-if, digest | Evals pass per persona |
| Pilot | Dink Battle format (section 10) | Pilot division runs at one event |
| Deferred | Timed matches, streaming, scorebug overlays, clip generation | Not scheduled |

## 9. Scope notes

- Timed matches were never part of Dinkster. They are a possible future initiative and are not in the MVP. Live rule pivots in the copilot change the target score (for example, games to 9) or the format, not the clock.

## 10. Dink Battle (pilot format)

Description as given by the founder: after the 5th shot of a rally, the court shrinks to half court. Dinks decide the point. Lobs and hard shots land out because the court is smaller.

Product handling:

- `ScoringMode.DINK_BATTLE`, with the rule values stored in `scoringConfig` JSON, for example `{"shrinkAfterShot":5,"courtScale":0.5}`. Values can change during the pilot without a migration.
- Player app: Game type selector on Host a game, a shot counter, a half court indicator, and an "Out by" action that awards the rally to the other side.
- Organizer app: pilot division flag on the event page. Copilot can draft a pilot division from one sentence and waits for confirm.
- Future pilot tournament: one Dink Battle division at a single event, then review results and player feedback before wider release.

Open rule questions before any official play:

1. Which half or what depth counts as half court (shorter toward the net, one side, or a diagonal).
2. How serve, return, and the kitchen work after the shrink.
3. How line calls are made when the boundary moves mid-rally.
4. Whether the shot count includes the serve and return.
5. Scoring and game length for the format.

IP note: confirm filing strategy with an IP attorney before sharing rules, mockups, or videos publicly. Public disclosure can affect patent rights in some countries.

## 11. Open items

- Confirm Supabase accepts the chosen auth path for the Apple Sign-in setup.
- Confirm Firebase data to migrate (users, games) and cutover date.
- Confirm DUPR API access terms.
- Confirm platform fee default (schema uses 10.00%, matching the mockup).
