# Dinkster mockup review: v3 to v4

Method: v3 file read and tested in a headless browser (all 210 clickable controls fired, handlers and ids checked). v4 tested the same way. No visual review of either.

## 1. v3 validation

| Check | Result |
|---|---|
| Controls clicked | 210, no script errors |
| Undefined handlers | None (two hits are built-in methods) |
| Duplicate ids | None |

Defects and contradictions found in v3:

1. **Scoring contradicts the locked decisions.** The lobby says side-out scoring with the two-server rule. The code gives a point to whichever team wins the rally and never moves the server number past 1. That is rally scoring. v4 uses traditional side-out scoring with two servers. Decision needed: which scoring does Dinkster use, or does the host choose?
2. **Best of 3 is cosmetic.** Set tabs show, but a win only triggers a browser "New game?" prompt. Sets are never stored.
3. **Browser prompt and confirm dialogs** are used for adding a guest and for the win message. Not suitable for production feel.
4. **Join keypad** carried hard-coded demo digits (7, 7, 4, 1) and the `DK-` prefix.
5. **Switch ends at 6** is built in. Verify against the rule set you follow before keeping it.
6. **Icons:** the tennis ball emoji is used for Players and Home in a pickleball app.
7. All data is mock and nothing persists.

## 2. v3 features missing from v4 (port candidates)

| Area | v3 had | v4 status | Priority |
|---|---|---|---|
| Home | Greeting, next game, quick actions, games forming nearby, matched player | Simple next-match card only | High |
| Lobby | Player slots with status, copy code, add guest (no app needed), skip toss, locked decisions list | Host form only | High |
| Live score | Best of 3 with set tabs, switch-ends prompt, rallies and side-out stats, share via iMessage, AirDrop, QR | Single game, no stats, no share | High |
| Coin toss | Pick heads or tails, winner picks serve, receive, or side | Auto flip, serves first | Medium |
| Players | Filter chips, super match star, verified badge | Swipe and list only | Medium |
| Courts | Claim a free court, booking confirmation with booking ID, calendar invite, start lobby from booking, My Sessions tab, eligible slots tied to benefits | Booking and benefits list, no confirmation screen | High |
| Profile | Multi-sport rows (pickleball DUPR verified, tennis phase 2, badminton phase 3), memberships with balances (WellHub check-ins, ClassPass credits, Aetna reimbursement, SilverSneakers, venue membership), coach earnings and specialties | Stats, history, connected list, coach rate | Medium |
| Watch | Tap to score, Digital Crown undo, complication, invite notification | Score view and notification | Medium |
| iPad | Sidebar with score, lobby, toss, players, courts, profile | Wider layout with tab rail | Low |

## 3. What v4 added

Events tab with registration, waiver, and payment. Court call and rule-change alerts. Player Copilot with score parsing. DUPR sync status. Pilot Dink Battle format. Web app for organizer, desk, and referee.

## 4. Evolution assessment

- v3 is deep on casual play, the Phase 1 core. v4 widened to tournaments and thinned casual play. That is a regression on the part of the product shipping first.
- Recommendation: v5 keeps v3 depth for casual play and keeps v4 additions. Port the High items first.

## 5. Changes made after review

- Play tab icon is now a pickleball (ball with holes).
- Join uses a text field with `D-` shown in front. The phone keyboard opens on its own. Input is uppercased, accepts a pasted `D-7K4M`, and Enter joins. A QR option remains.
- Game codes use the `D-` prefix. Player IDs stay `DK-XXXXX`. Confirm the two prefixes should differ.

## 6. Schema gaps these features expose

1. Game join code (`D-XXXX`): needs a unique active code on casual matches.
2. Guest players with no app: `MatchParticipant.userId` is required today. Needs a guest name option.
3. Best of 3: needs match format fields (sets to win, points per set, win by).
4. Benefit balances (check-ins, credits, reimbursement caps): no tables yet.
5. Multi-sport ratings: User holds one DUPR rating. Needs a per-sport rating table.

## 7. v5 audit log (mobile v5, web v5)

Method: every screen rendered in a headless browser and reviewed as an image, every control clicked, theme token contrast computed for all 5 themes. Fonts did not load in the test renders (system fallback used).

### Defects found in v4 and fixed

| # | Defect | Fix |
|---|---|---|
| 1 | Theme palettes did not match v3 (Neon Rave was dark, Y2K lavender, Clean Slate and Warm Studio wrong colors) | Copied v3 tokens exactly |
| 2 | Fonts changed without approval | Restored v3 fonts: Syne, DM Sans, DM Mono |
| 3 | Demo data diverged from v3 (real founder name, invented venues, players, teams) | v3 persona (Alex Johnson, DK-X7K2P), v3 players and courts, AJ & MR vs JC & SK |
| 4 | Mobile and web used different event, team, and court names | Aligned: Dink Masters Open, Johnson / Rivera, Court 8 call |
| 5 | Play icon read as a basketball | Pickleball icon, Home icon for the tab |
| 6 | Join keypad | Type-in D code field, OS keyboard, paste and Enter work |
| 7 | Coin toss result ignored, wrong team served first | Toss winner now sets first server |
| 8 | Floating Copilot button covered content and tags | Moved to header |
| 9 | Score screen: rally buttons pushed off screen, Dink panel too tall | Compact layout |
| 10 | Watch buttons labeled "+AM" | "+AJ&MR" |
| 11 | "Wellhub", "Classpass" capitalization | WellHub, ClassPass |
| 12 | Profile showed 3 games, 67% win rate from mock rows | v3 base 47 games, 62%, updates with play |
| 13 | Contrast failures (danger button 3.7 to 3.9, free pin, muted tag) | Fixed, all 5 themes pass body, muted, button, and tag pairs |
| 14 | iPad: swipe buttons separated from the card | Kept together |
| 15 | Web dashboard bar implied a meaning it did not have | Planned vs projected finish with minutes saved |
| 16 | Web dispute buttons were the same for every dispute | Options per dispute type |
| 17 | Founder name in web change log | Generic organizer |

### v3 depth ported into v5 mobile

Home dashboard with nearby games and quick actions. Lobby with player slots, guest players without the app, team name edit, skip toss. Best of 3 with set tabs and stats. Switch-ends prompt (v3 behavior). Share row. Heads or tails pick with serve, receive, or side choice. Players filters, super match, verified badge. Free court claim. Booking with slot prices, confirmation ID, and Start lobby. My Sessions in coach mode. Benefits by venue with slot pick and notes. Multi-sport profile with phase tags, memberships with balances, coach profile. Watch Digital Crown undo and invite notification.

### Assumptions to confirm

1. Switch ends when the first team reaches 6 is carried over from v3. Verify against your rules.
2. Toss winner picking a side gives first serve to the other team (assumed).
3. In best of 3, the first server alternates each set (assumed).
4. Scoring follows your locked decisions: side-out scoring, two-server rule in doubles.
5. Dink Battle open rule questions in ARCHITECTURE.md section 10.
6. Game codes use `D-`, player IDs keep `DK-`.

### Not verified

Real iOS and Android keyboard behavior for the D code field (attributes set, not tested on devices). Font rendering. Keyboard-only navigation by hand. Contrast was computed for token pairs, not every rendered combination.
