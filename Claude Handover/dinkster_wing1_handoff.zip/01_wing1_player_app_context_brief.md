# Dinkster Wing 1: Player App. Context Brief (v2)

Prepared Tuesday, October 20, 2026. Supersedes the earlier brief dated October 19.
Purpose: give Claude enough context to work on the player-facing app as one wing of the larger Dinkster platform.

**Source tags.** `[DOC]` architecture doc v1.0, March 2026. `[MOCK2]` mockup v2 file. `[MOCK41]` mockup v4.1 in this folder. `[NOTES]` your stated decisions and project notes. `[WEB]` Expo plugin pages retrieved October 19. `[DERIVED]` my synthesis.
**Confidence.** High: stated in your own files or notes. Medium: inferred from several of them, or from third-party pages. Low: my judgment, not confirmed by any source.

**Correction to the earlier brief.** The first brief led with scoring as the front door. Your stated core is Tinder-style social discovery. This version fixes that and flags the resulting tension in section 1, item 2.

---

## 1. Hard truths first

1. **Nothing runs on a device yet.** The React Native scaffold v1 exists. The April 10 to 14 TestFlight sprint passed without completion, with auth screens, profile setup with Dinkster ID, score tracker port, and lobby/join screens still outstanding. The HTML mockup is the only working artifact. `[NOTES]` High. Re-verify before planning.
2. **Your stated core and the current build order disagree.** Your core is social discovery (swipe, interaction-focused) to get people playing together. But Phase 1 in `[NOTES]` and `[DOC]` is scoring plus Watch, with discovery in Phase 2. And mockup v4.1 Home leads with game actions, with Players as one tab. Discovery also has a cold-start problem: it is empty without nearby players, while scoring works with one phone and a watch. My recommendation (Low to Medium confidence): ship scoring in the first TestFlight because it needs no density, and build discovery plus check-in as the growth engine immediately after. If discovery must lead, the first release needs a seeded or invite-only player pool. This is a decision for you, listed in section 8.
3. **The architecture doc is partly stale.** It commits to GCP, Firebase, Cloud SQL, and a 4 to 5 person team at $456,500 to $754,400. Your notes say the backend is undecided and wing-driven, and offline sync is not a concern, while the doc specifies an offline score cache. Treat the doc's team, cost, and backend sections as stale. `[DOC]` `[NOTES]` High.
4. **Wing 1 cannot carry the business.** The doc's own model shows revenue of $9,510 against cost of $17,500 per month at 10,000 MAU, a net of -$8,822. The revenue lines (booking commission, Pro, Club, featured placement) mostly depend on courts and operators. `[DOC]` section 15.6 High. That these belong to other wings is `[DERIVED]` Low.
5. **The Watch build path in the doc will break.** The doc plans a separate Xcode watch target. A manually added watch target is destroyed the next time `expo prebuild` runs. The working pattern is a config plugin that regenerates the target (`@bacons/apple-targets`, type `watch`) plus a WatchConnectivity module. That plugin describes itself as experimental and not part of the official Expo workflow. `[WEB]` Medium. Unverified: whether the watch target builds through EAS from Windows without Xcode access. Test before committing Watch to the first TestFlight.
6. **Check-in location rules are simulated in the mockup.** Real phone location can be spoofed and is unreliable indoors. The real build needs a plan for both. `[DERIVED]` Medium.
7. **The mockup scoring rules are not final.** Side-out versus rally scoring, and whether sides switch at 6 in every set or only in a deciding set, are not decided. v4.1 uses side-out scoring and a switch prompt at 6 in every set (carried from v2). `[MOCK41]` High that these are open.

---

## 2. Essence

**Wing 1 gets people from "I want to play" to playing together, then runs the game and remembers the result.** `[DERIVED]` Medium, built on your stated core.

The player loop:

1. **Find people:** swipe discovery by level and time, and "Here now" at the court you are at.
2. **Agree to play:** a request, accepted by the other person, then chat.
3. **Run the game:** lobby, toss, live score on phone and watch, each device holding a role.
4. **Keep the record:** match saved to a permanent Dinkster ID with ratings and history.

Wing 1 is the player audience only. Organizer features (court desk, hosting and registration, copilot) are a different audience and stay out of the player app. `[NOTES]` High.

## 3. Intent: why it exists

- Social sports apps fail on the first step: finding someone at your level, at your time, nearby, who you are comfortable meeting. Discovery plus check-in targets that step. `[DERIVED]` Medium.
- The on-court tools (scoring, Watch, multi-device roles) are what bring players back every game and give the app a real-world hook that a pure matching app lacks. `[DERIVED]` Medium.
- The Dinkster ID and match record are what make discovery trustworthy over time: level and history are visible before you meet. `[DERIVED]` Medium.
- Pickleball first, then tennis (Phase 2), then badminton (Phase 3). Watch is Phase 1. `[NOTES]` High.
- Benefits Aggregator (WellHub, ClassPass, insurance reimbursement) is a stated differentiator. `[NOTES]` High. Coverage mechanics are not specified.

## 4. How it is built

| Area | Decision | Source | Confidence |
|---|---|---|---|
| Client | React Native, Expo (EAS builds), TypeScript, TestFlight first | NOTES | High |
| Build host | Windows, tested on iPhone 15 Pro Max and Apple Watch | NOTES | High |
| Watch | Swift/WatchKit target, WatchConnectivity to phone | DOC, NOTES | High |
| Real-time | Firestore listeners, optimistic local update, under 200 ms target on WiFi (a target, not a measurement) | DOC section 8 | High |
| Backend | Not decided, driven by wing requirements | NOTES | High |
| Identity | Dinkster ID `DK-XXXXX`, permanent, ratings per sport | NOTES | High |
| Game code | `D-` prefix, entered in a text field so the OS keyboard opens (no custom keypad) | NOTES | High |
| Icons | Pickleball paddle and ball, not basketball-style | NOTES | High |
| Process | Mockup first to lock decisions, then port to RN. Separate mockups for player (mobile) and organizer (web) | NOTES | High |
| Infra IDs | GCP project `dinkster`, repo `AimmanniGit/dinkster`, bundle ID `app.dinkster.mobile` | NOTES | High |

**Locked product decisions** `[NOTES]` High:
- Team names default to player initials, editable inline by the host.
- Singles and doubles from Phase 1, toggled in the lobby.
- Host override wins score disputes and is silent to non-host players.
- Singles: the server keeps serving until they lose the rally.
- Doubles: two-server rule, a side out changes the serving team.
- Offline sync is not a concern now. Timed matches are not part of Dinkster.

## 5. Features in mockup v4.1

| Area | What it does |
|---|---|
| Home | Next game card, Quick actions, nearby suggestions, check-in status card when checked in |
| Quick actions | Customizable: up to 6, 4 by default (New game, Join a game, Coin toss, Check in). Pool also has Find players, My Dinkster ID, Find a court. Saved in the browser |
| Lobby | Singles or doubles, editable team names, guest add, Dink Battle shown as coming soon |
| Toss | Call, flip, winner chooses serve, receive, or side |
| Live score | Side-out scoring with server 1 and 2, best of 3 to 11 win by 2, rally outcome preview, undo, silent host adjust, side-switch prompt, result sheet, save to profile |
| Join | Typed `D-` code, wrong-code error, role picker (scorer, watch, camera, spectator). Spectators cannot score |
| Apple Watch panel | Synced to the same game, tap to score |
| Players | Swipe by drag or buttons, list view, level filter, match sheet |
| Courts | Map with pins, filters (free, paid, indoor, covered by benefits), booking sheet with 10% fee, here-now counts |
| Check in | See section 6 |
| Profile | Dinkster ID, DUPR, stats and history that update after a saved match |

All people, courts, and prices are sample data.

## 6. Check-in and nearby players (new)

**Idea.** At a club or open public court, a player checks in. Others checked in there see their level and what they want, and can ask to play, even if they never met. `[NOTES]` High that this is wanted.

**Safety design in the mockup** `[DERIVED]` Medium:
- Check-in works only when the phone is at the court (simulated).
- Check-in expires on its own after 2 hours.
- Others see first name plus initial, DUPR, the court, and what you want. Never a map position.
- Only players checked in at the same court see you.
- Open to play is a switch. Off hides you but you can still see who is there.
- Optional switch: only show me to similar levels (within 0.5 DUPR).
- No free messaging. A fixed-format Ask to play request, and chat opens only after the other person accepts.
- Block, and report and block, on every person.

**Where it lives.** The Courts tab is the primary home (check-in belongs to a place). Entry points: court cards, Home status card, and an optional Quick action. A "Here now" segment on the Players tab is a later option. In the feature list it belongs with discovery and messaging as "Nearby play". Real venue data comes from the court desk wing. `[DERIVED]` Low to Medium.

**Needs to be decided before building** (section 8): real name versus display name, visibility to everyone at the court versus similar levels only, age rules, and App Store location and user-safety review requirements (not verified).

## 7. Boundaries and evolution

Wing names from your notes: player app, court desk, hosting and registration, agentic copilot. What each wing owns beyond its name is my proposal. `[DERIVED]` Low.

| Wing | Wing 1 gives | Wing 1 receives |
|---|---|---|
| 2 Court desk | Booking requests, check-in events, player reference | Court inventory, availability, prices, confirmations |
| 3 Hosting and registration | Player ID, rating, match results | Events a player can enter, brackets, schedules |
| 4 Agentic copilot | Event stream of games, requests, and results | Suggested partners, courts, times |

Rules that keep Wing 1 independent `[DERIVED]` Low to Medium:
1. Works with every other wing switched off.
2. Owns four records and exposes them by ID: player, game, match, rating. Add presence (check-in) as a fifth, with automatic expiry.
3. Emits events and does not call other wings directly.
4. Sport rules are data, not code paths: pickleball, tennis, badminton, and Dink Battle plug in as rule sets. Dink Battle (court shrinks to half after the 5th shot) is wanted as a feature or pilot tournament, with a trademark or patent plan. No rules spec exists yet. `[NOTES]` High.
5. Organizer features never appear in the player app.

| Stage | Goal | Done when |
|---|---|---|
| Now | Prove the loop on real devices | Two phones and a watch score one game saved to a real ID, via TestFlight |
| Next | Make it social | Join by code in the wild, discovery with a seeded pool, check-in at a small number of courts |
| Then | Make it transactional | Booking handoff to the court desk, ratings pulled from DUPR |
| Later | Make it broader | Tennis rule set, Dink Battle, benefits aggregator, copilot suggestions |

Metrics from the first TestFlight `[DERIVED]` Low: games scored per user per week, share of games with 3 or more devices, share of games saved, requests sent and accepted per check-in, and games that started from a request.

## 8. Open decisions

1. **Build order:** scoring first, discovery first, or both in the first TestFlight (section 1, item 2).
2. **Backend:** wing-driven choice pending. Presence with expiry and real-time chat affect it.
3. **Scoring system:** side-out (v4.1) or rally scoring, per format.
4. **Side switch rule:** every set at 6 (v2, v4.1) or only the deciding set.
5. **Booking fee:** 10% (mockup) or 10 to 15% (doc).
6. **DUPR link:** the doc says API or manual entry. Verification status is unconfirmed, v4.1 shows a plain DUPR value.
7. **Benefits aggregator:** how coverage is checked is not specified. v4.1 shows a labeled mock only.
8. **Check-in:** real versus display name, visibility rules, age rules, spoofing and indoor accuracy plan, store policy review.
9. **Dink Battle:** rules, trademark or patent route, ship as mode or pilot event.
10. **Next game card on Home:** you said it looks odd and you have a new mockup. It was not received, so the card is unchanged.
11. **Organizer web mockup:** not built. Only the player mobile mockup exists.
12. **v3 features not in v4.1:** five themes, coach/player mode, iPad split layout, Apple Watch complication and notification views, benefits aggregator tabs. v3 is not in the project files, so they were not ported.

## 9. Changes since the first v4

- Quick actions: icons (paddle and ball for New game), Find a court out of the default four, customizable up to 6.
- Check-in and nearby players added (section 6).
- Game code prefix changed from `DK-` to `D-` to match your rule. The Dinkster ID keeps `DK-`. This removes the earlier prefix collision.
- Full self-review run on v4.1. Results are in `02_mockup_self_review.md`.
