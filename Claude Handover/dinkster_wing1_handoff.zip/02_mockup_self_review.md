# Mockup v4.1 Self-Review

File: `dinkster_player_app_mockup_v4_1.html`. Reviewed Tuesday, October 20, 2026.
Method: static checks on the file, plus 45 automated checks that drive the page's own JavaScript with a stubbed page. Everything below marked "Verified" was run. Everything under "Not verified" was not.

## Verified

| Area | Check | Result |
|---|---|---|
| File | HTML tags balanced, no duplicate ids | Pass |
| File | No em or en dashes in the file | Pass |
| File | Only external resource is Google Fonts | Pass |
| Handlers | All 48 click handlers used in the static and generated markup point to defined functions | Pass |
| Quick actions | Default is 4 (New game, Join a game, Coin toss, Check in), Find a court not in default | Pass |
| Quick actions | Up to 6 allowed, 7th blocked, minimum 1 kept, reset restores default | Pass |
| Scoring | Doubles: receiving team winning a rally gives side out at server 1, second server at server 1 | Pass |
| Scoring | Undo restores server number and score | Pass |
| Scoring | Set 1 recorded at 11, next set starts with the other team serving, best of 3 decides the match | Pass |
| Scoring | Win by 2 enforced (11 to 10 does not end a set) | Pass |
| Scoring | Singles: server loses rally means side out, server number stays 1 | Pass |
| Scoring | Side-switch prompt appears when a team reaches 6 | Pass |
| Scoring | Spectator role cannot score | Pass |
| Scoring | Host adjust changes score silently and can end a set | Pass |
| Match | Saving a match updates games count and history, clears the live game | Pass |
| Toss | Receive, serve, and side choices set the right first server | Pass |
| Toss | Start from toss begins the game with that server | Pass |
| Join | Correct code `7741` enables the button, wrong code shows an error naming the typed `D-` code | Pass |
| Players | Swiping consumes the deck, level filter limits to 3.0 to 4.0 | Pass |
| Courts | Benefits filter shows only covered courts | Pass |
| Booking | 1.5 hr at $32 shows $48.00, fee $4.80 (10%), total $52.80 | Pass |
| Booking | Benefit payment option shows $0.00 total, free courts show Free | Pass |
| Booking | Confirmed booking appears on the Home card | Pass |
| Check-in | Check-in blocked when the demo phone is elsewhere or at a different court | Pass |
| Check-in | Expires 2 hours after check-in, demo expiry checks out automatically | Pass |
| Check-in | Ask to play sends a request that names the sender, level, format, and court | Pass |
| Check-in | Open to play off disables Ask to play | Pass |
| Check-in | Block removes the person from Here now | Pass |
| Check-in | Check out clears requests | Pass |
| Check-in | Home shows a status card while checked in, court cards show here-now counts | Pass |

## Not verified

- **Real browser rendering.** Layout, spacing, and fonts were not viewed in a browser. Please open the file and look at every screen.
- **Emoji icons.** 🔗 🪙 📍 🙋 👥 🪪 look different on each operating system. The paddle and ball icon is custom artwork.
- **Touch behavior.** Drag-to-swipe on the Players card was written for pointer events but not tested on a phone.
- **Clipboard.** The copy code button depends on the browser allowing clipboard access.
- **Saved Quick actions.** Saving uses browser storage, which can be blocked when the file is opened from disk in some browsers. The page still works, it just will not remember your selection.
- **Apple Watch panel.** This is a visual stand-in, not a real watch.
- **Check-in location rule.** Simulated with the "Demo only" chips. Real location, spoofing, and indoor accuracy are not tested.
- **Accepted requests.** Everyone accepts after about 2 seconds except Jordan, to show a pending state. This is scripted.

## Known gaps

- Next game card on Home is unchanged. The new mockup you mentioned was not received.
- Features in v3 that are not in v4.1: five themes, coach/player mode, iPad split layout, Apple Watch complication and notification views, benefits aggregator tabs.
- Organizer web mockup does not exist.
